// ═══════════════════════════════════════════════════════════════
//  EMPLOYEE MANAGEMENT MODULE
// ═══════════════════════════════════════════════════════════════

function initEmployees() {
    const view = document.getElementById('view-employees');
    view.innerHTML = `

        <!-- ══ LEDGER MODAL ══════════════════════════════════ -->
        <div id="salary-modal" style="display:none;position:fixed;inset:0;background:rgba(10,15,30,0.88);z-index:300;align-items:center;justify-content:center;backdrop-filter:blur(10px);">
            <div style="background:#1a2540;border:1px solid rgba(255,255,255,0.1);border-radius:18px;padding:28px;width:680px;max-height:82vh;overflow-y:auto;box-shadow:0 20px 50px rgba(0,0,0,0.5);">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
                    <h3 id="modal-emp-name" style="font-size:1.1rem;color:#f8fafc;">Salary Ledger</h3>
                    <button onclick="document.getElementById('salary-modal').style.display='none'"
                        style="background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.12);color:#94a3b8;border-radius:50%;width:34px;height:34px;cursor:pointer;font-size:1rem; display:flex; align-items:center; justify-content:center;"><i data-lucide="x" style="width:16px;"></i></button>
                </div>
                <div class="table-container" style="margin-top:0;">
                    <table style="width:100%;font-size:0.88rem;">
                        <thead><tr>
                            <th>Date</th><th>Type</th>
                            <th style="text-align:right">Earned</th>
                            <th style="text-align:right">Paid</th>
                            <th style="text-align:right">Running Balance</th>
                            <th style="width:40px;"></th>
                        </tr></thead>
                        <tbody id="modal-history-body"></tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ══ ADD EMPLOYEE ═══════════════════════════════════ -->
        <div style="background:#1a2540;border:1px solid rgba(255,255,255,0.08);border-radius:14px;padding:18px 22px;margin-bottom:20px;">
            <div style="font-size:0.75rem;color:#10b981;font-weight:700;text-transform:uppercase;letter-spacing:1px;margin-bottom:12px; display:flex; align-items:center; gap:6px;"><i data-lucide="user-plus" style="width:14px;"></i> Add New Employee</div>
            <div style="display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap;">
                <div style="flex:2;min-width:130px;">
                    <label style="font-size:0.78rem;color:#64748b;display:block;margin-bottom:4px;">Name *</label>
                    <input type="text" id="emp-name" placeholder="e.g. Ravi Kumar" style="margin:0;padding:11px 13px;">
                </div>
                <div style="flex:1.2;min-width:110px;">
                    <label style="font-size:0.78rem;color:#64748b;display:block;margin-bottom:4px;">Role</label>
                    <input type="text" id="emp-role" placeholder="Baker / Helper" style="margin:0;padding:11px 13px;">
                </div>
                <div style="flex:1;min-width:100px;">
                    <label style="font-size:0.78rem;color:#64748b;display:block;margin-bottom:4px;">Daily Wage (₹) *</label>
                    <input type="number" id="emp-wage" placeholder="500" style="margin:0;padding:11px 13px;">
                </div>
                <button onclick="window.addEmployee()"
                    style="background:#10b981;color:white;border:none;border-radius:10px;padding:11px 20px;font-weight:700;cursor:pointer;font-family:inherit;white-space:nowrap;font-size:0.9rem;">
                    + Add
                </button>
            </div>
        </div>

        <!-- ══ STATS + ACTIONS BAR ════════════════════════════ -->
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;flex-wrap:wrap;gap:10px;">
            <div id="emp-summary" style="display:flex;gap:10px;flex-wrap:wrap;"></div>
            <button onclick="window.clearAllData()"
                style="background:rgba(239,68,68,0.1);color:#f87171;border:1px solid rgba(239,68,68,0.25);border-radius:9px;padding:9px 16px;font-size:0.82rem;font-weight:600;cursor:pointer;font-family:inherit;white-space:nowrap; display:flex; align-items:center; gap:6px;"
                onmouseover="this.style.background='rgba(239,68,68,0.22)'"
                onmouseout="this.style.background='rgba(239,68,68,0.1)'">
                <i data-lucide="trash-2" style="width:14px;"></i> Clear All Data
            </button>
        </div>

        <!-- ══ MAIN TABLE ═════════════════════════════════════ -->
        <div style="background:#1a2540;border:1px solid rgba(255,255,255,0.07);border-radius:14px;overflow:hidden;">
            <table style="width:100%;border-collapse:collapse;text-align:left;" id="emp-main-table">
                <thead>
                    <tr style="background:rgba(255,255,255,0.03);">
                        <th style="padding:13px 16px;font-size:0.73rem;color:#64748b;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid rgba(255,255,255,0.06);">Employee</th>
                        <th style="padding:13px 16px;font-size:0.73rem;color:#64748b;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid rgba(255,255,255,0.06);">Daily<br>Wage</th>
                        <th style="padding:13px 16px;font-size:0.73rem;color:#64748b;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid rgba(255,255,255,0.06);text-align:center;">Today's<br>Attendance</th>
                        <th style="padding:13px 16px;font-size:0.73rem;color:#64748b;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid rgba(255,255,255,0.06);text-align:right;">Today<br>Paid</th>
                        <th style="padding:13px 16px;font-size:0.73rem;color:#64748b;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid rgba(255,255,255,0.06);text-align:right;">Paid This<br>Month</th>
                        <th style="padding:13px 16px;font-size:0.73rem;color:#64748b;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid rgba(255,255,255,0.06);text-align:right;">Still to<br>Pay</th>
                        <th style="padding:13px 10px;font-size:0.73rem;color:#64748b;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;border-bottom:1px solid rgba(255,255,255,0.06);text-align:center;"></th>
                    </tr>
                </thead>
                <tbody id="emp-body">
                    <tr><td colspan="7" style="padding:50px;text-align:center;color:#64748b;font-style:italic;">No employees yet — add one above.</td></tr>
                </tbody>
            </table>
        </div>
    `;

    renderEmployees();
}

// ─── Add Employee ─────────────────────────────────────────────────────────────
window.addEmployee = () => {
    const name      = document.getElementById('emp-name').value.trim();
    const role      = document.getElementById('emp-role').value.trim();
    const dailyWage = parseFloat(document.getElementById('emp-wage').value);

    if (!name)                      return showToast('Please enter the employee name.', 'error');
    if (!dailyWage || dailyWage<=0) return showToast('Please enter a valid daily wage.', 'error');

    let emps = JSON.parse(localStorage.getItem('mj_employees') || '[]');
    emps.push({ id: Date.now().toString(), name, role, dailyWage });
    localStorage.setItem('mj_employees', JSON.stringify(emps));

    document.getElementById('emp-name').value = '';
    document.getElementById('emp-role').value = '';
    document.getElementById('emp-wage').value = '';
    document.getElementById('emp-name').focus();

    showToast(`${name} added!`, 'success');
    renderEmployees();
};

// ─── Remove Employee ──────────────────────────────────────────────────────────
window.removeEmployee = (empId) => {
    if (!confirm('Remove this employee?')) return;
    let emps = JSON.parse(localStorage.getItem('mj_employees') || '[]');
    emps = emps.filter(e => e.id !== empId);
    localStorage.setItem('mj_employees', JSON.stringify(emps));
    showToast('Employee removed.', 'info');
    renderEmployees();
};

// ─── Clear ALL salary data ────────────────────────────────────────────────────
window.clearAllData = () => {
    if (!confirm('⚠️ This will permanently delete ALL salary records for ALL employees.\n\nEmployee profiles will be kept. Are you sure?')) return;
    localStorage.removeItem('mj_emp_ledger');
    showToast('All salary data cleared.', 'info');
    renderEmployees();
    if (window.refreshDashboard) window.refreshDashboard();
};

// ─── Record Log ───────────────────────────────────────────────────────────────
window.recordDailyLog = (empId, type, earned, paid) => {
    const dateStr = new Date().toDateString();
    let logs = JSON.parse(localStorage.getItem('mj_emp_ledger') || '[]');

    if (type === 'WORKED') {
        if (logs.find(l => l.empId === empId && l.dateStr === dateStr && l.type === 'WORKED')) {
            return showToast("Today already logged. Use 'Pay Dues' to add a payment.", 'error');
        }
    }

    logs.push({ id: Date.now(), empId, type, dateStr, timestamp: Date.now(), earned, paid });
    localStorage.setItem('mj_emp_ledger', JSON.stringify(logs));
    renderEmployees();
    if (window.refreshDashboard) window.refreshDashboard();
};

// ─── Clear Today's Entry ──────────────────────────────────────────────────────
window.clearTodayLog = (empId) => {
    const todayStr = new Date().toDateString();
    let logs = JSON.parse(localStorage.getItem('mj_emp_ledger') || '[]');
    const entry = logs.find(l => l.empId===empId && l.dateStr===todayStr && l.type==='WORKED');
    if (!entry) return;
    if (!confirm("Clear today's entry for this employee?")) return;
    logs = logs.filter(l => l.id !== entry.id);
    localStorage.setItem('mj_emp_ledger', JSON.stringify(logs));
    showToast("Today's entry cleared.", 'info');
    renderEmployees();
    if (window.refreshDashboard) window.refreshDashboard();
};

// ─── Delete single ledger entry ───────────────────────────────────────────────
window.deleteLogEntry = (logId, empId) => {
    if (!confirm('Delete this entry?')) return;
    let logs = JSON.parse(localStorage.getItem('mj_emp_ledger') || '[]');
    logs = logs.filter(l => l.id !== logId);
    localStorage.setItem('mj_emp_ledger', JSON.stringify(logs));
    showToast('Entry deleted.', 'info');
    renderEmployees();
    // refresh ledger modal if open
    const modal = document.getElementById('salary-modal');
    if (modal && modal.style.display === 'flex') window.viewEmployeeLedger(empId);
    if (window.refreshDashboard) window.refreshDashboard();
};

// ─── Mark Attendance (single action) ─────────────────────────────────────────
window.markAttendance = (empId, wage) => {
    const input  = document.getElementById(`pay-amt-${empId}`);
    const paid   = input ? parseFloat(input.value) : wage;
    if (isNaN(paid) || paid < 0 || paid > wage)
        return showToast(`Enter a valid amount between 0 and ${wage}.`, 'error');
    window.recordDailyLog(empId, 'WORKED', wage, paid);
    const msg = paid === wage ? 'Attendance marked — full pay!' :
                paid === 0   ? 'Attendance marked — ₹0 paid today.' :
                               `Attendance marked — ₹${paid} paid.`;
    showToast(msg, 'success');
};
window.payDues = (empId, pending) => {
    const input  = document.getElementById(`dues-${empId}`);
    const amount = parseFloat(input ? input.value : pending);
    if (isNaN(amount) || amount <= 0 || amount > pending)
        return showToast(`Enter amount between 1 and ${pending}.`, 'error');
    window.recordDailyLog(empId, 'PAYMENT', 0, amount);
    showToast(`₹${amount} dues cleared!`, 'success');
};

// ─── PILL HELPER ──────────────────────────────────────────────────────────────
function pill(iconName, text, color) {
    return `<div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.07);border-radius:9px;padding:8px 14px;display:flex;align-items:center;gap:7px;">
        <i data-lucide="${iconName}" style="width:16px; color:${color}"></i>
        <span style="font-size:0.82rem;font-weight:600;color:${color};">${text}</span>
    </div>`;
}

// ─── RENDER ───────────────────────────────────────────────────────────────────
function renderEmployees() {
    const emps     = JSON.parse(localStorage.getItem('mj_employees') || '[]');
    const logs     = JSON.parse(localStorage.getItem('mj_emp_ledger') || '[]');
    const now      = new Date();
    const todayStr = now.toDateString();
    const thisMonth = now.getMonth();
    const thisYear  = now.getFullYear();

    const body    = document.getElementById('emp-body');
    const summary = document.getElementById('emp-summary');
    if (!body) return;

    if (emps.length === 0) {
        body.innerHTML = `<tr><td colspan="7" style="padding:50px;text-align:center;color:#64748b;font-style:italic;">No employees yet — add one above.</td></tr>`;
        if (summary) summary.innerHTML = '';
        return;
    }

    let totalPendingAll = 0, loggedToday = 0, totalPaidMonthAll = 0;

    const rows = emps.map(emp => {
        const empLogs = logs.filter(l => l.empId === emp.id);

        // ── All-time totals ──
        const totalEarned  = empLogs.reduce((a, c) => a + c.earned, 0);
        const totalPaidAll = empLogs.reduce((a, c) => a + c.paid,   0);
        const pendingDues  = totalEarned - totalPaidAll;

        // ── This month's totals ──
        const monthLogs    = empLogs.filter(l => {
            const d = new Date(l.timestamp);
            return d.getMonth() === thisMonth && d.getFullYear() === thisYear;
        });
        const paidThisMonth   = monthLogs.reduce((a, c) => a + c.paid,   0);
        const daysWorkedMonth = monthLogs.filter(l => l.type === 'WORKED').length;

        // ── Today ──
        const todayEntry   = empLogs.find(l => l.dateStr === todayStr && l.type === 'WORKED');
        const workedToday  = !!todayEntry;
        const todayPaid    = todayEntry ? todayEntry.paid : 0;

        // ── Accumulators ──
        totalPendingAll  += pendingDues;
        totalPaidMonthAll += paidThisMonth;
        if (workedToday) loggedToday++;

        // ── Today's attendance cell ──
        let attendanceCell;
        if (workedToday) {
            const paidLabel = todayEntry.paid === todayEntry.earned
                ? `<span style="color:#34d399;font-weight:700;">₹${todayEntry.paid.toLocaleString('en-IN')} paid (full)</span>`
                : todayEntry.paid === 0
                    ? `<span style="color:#f87171;font-weight:700;">₹0 paid</span>`
                    : `<span style="color:#fbbf24;font-weight:700;">₹${todayEntry.paid.toLocaleString('en-IN')} paid</span>`;
            attendanceCell = `
                <div style="display:flex;flex-direction:column;align-items:center;gap:5px;">
                    <span style="background:rgba(16,185,129,0.1);color:#34d399;border:1px solid rgba(16,185,129,0.2);border-radius:20px;padding:3px 12px;font-size:0.75rem;font-weight:600; display:flex; align-items:center; gap:4px;"><i data-lucide="check" style="width:12px;"></i> Attended</span>
                    ${paidLabel}
                    <button onclick="window.clearTodayLog('${emp.id}')"
                        title="Undo today's entry"
                        style="background:rgba(239,68,68,0.08);color:#f87171;border:1px solid rgba(239,68,68,0.2);border-radius:6px;padding:3px 10px;font-size:0.72rem;font-weight:600;cursor:pointer;font-family:inherit; display:flex; align-items:center; gap:4px;"
                        onmouseover="this.style.background='rgba(239,68,68,0.22)'"
                        onmouseout="this.style.background='rgba(239,68,68,0.08)'"><i data-lucide="rotate-ccw" style="width:12px;"></i> Clear Entry</button>
                </div>`;
        } else {
            attendanceCell = `
                <div style="display:flex;align-items:center;justify-content:center;gap:6px;">
                    <div style="display:flex;flex-direction:column;align-items:flex-start;gap:3px;">
                        <label style="font-size:0.68rem;color:#64748b;">Paid Today (₹)</label>
                        <input id="pay-amt-${emp.id}" type="number"
                            value="${emp.dailyWage}" min="0" max="${emp.dailyWage}"
                            style="width:90px;padding:7px 9px;background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.12);border-radius:8px;color:#f8fafc;font-size:0.88rem;font-family:inherit;font-weight:600;">
                    </div>
                    <button onclick="window.markAttendance('${emp.id}',${emp.dailyWage})"
                        style="background:rgba(16,185,129,0.15);color:#34d399;border:1px solid rgba(16,185,129,0.3);border-radius:8px;padding:10px 14px;font-size:0.82rem;font-weight:700;cursor:pointer;font-family:inherit;white-space:nowrap;margin-top:14px; display:flex; align-items:center; gap:6px;"
                        onmouseover="this.style.background='rgba(16,185,129,0.28)'"
                        onmouseout="this.style.background='rgba(16,185,129,0.15)'"><i data-lucide="check-square" style="width:14px;"></i> Mark Attendance</button>
                </div>`;
        }

        let stillToPayCell;
        if (pendingDues > 0) {
            stillToPayCell = `
                <div>
                    <div style="color:#ef4444;font-weight:700;font-size:0.95rem;">₹${pendingDues.toLocaleString('en-IN')}</div>
                    <div style="font-size:0.7rem;color:#64748b;margin-top:2px;">dues pending</div>
                    <div style="display:flex;gap:4px;margin-top:6px;align-items:center;">
                        <input id="dues-${emp.id}" type="number" value="${pendingDues}" min="1" max="${pendingDues}"
                            style="width:70px;padding:5px 7px;background:rgba(0,0,0,0.3);border:1px solid rgba(239,68,68,0.2);border-radius:6px;color:#f8fafc;font-size:0.78rem;font-family:inherit;">
                        <button onclick="window.payDues('${emp.id}',${pendingDues})"
                            style="background:rgba(245,158,11,0.12);color:#fbbf24;border:1px solid rgba(245,158,11,0.25);border-radius:6px;padding:5px 9px;font-size:0.78rem;font-weight:600;cursor:pointer;font-family:inherit;">Pay</button>
                    </div>
                </div>`;
        } else {
            stillToPayCell = `<span style="color:#34d399;font-weight:600;font-size:0.85rem; display:flex; align-items:center; gap:4px;"><i data-lucide="check-circle" style="width:14px;"></i> No dues</span>`;
        }

        return `
        <tr style="border-bottom:1px solid rgba(255,255,255,0.05);transition:background 0.15s;"
            onmouseover="this.style.background='rgba(255,255,255,0.02)'"
            onmouseout="this.style.background='transparent'">
            <td style="padding:13px 16px;">
                <div style="font-weight:700;color:#f1f5f9;font-size:0.95rem;">${emp.name}</div>
                <div style="font-size:0.75rem;color:#64748b;margin-top:2px;">${emp.role || '—'}</div>
            </td>
            <td style="padding:13px 16px;">
                <div style="font-weight:700;color:#10b981;font-size:0.95rem;">₹${emp.dailyWage.toLocaleString('en-IN')}</div>
                <div style="font-size:0.7rem;color:#64748b;margin-top:2px;">per day</div>
            </td>
            <td style="padding:13px 16px;text-align:center;">${attendanceCell}</td>
            <td style="padding:13px 16px;text-align:right;">
                ${workedToday
                    ? `<div style="font-weight:700;font-size:0.95rem;color:${todayPaid > 0 ? '#34d399' : '#f87171'};">₹${todayPaid.toLocaleString('en-IN')}</div>
                       <div style="font-size:0.7rem;color:#64748b;margin-top:2px;">${todayPaid === emp.dailyWage ? 'full' : todayPaid === 0 ? 'not paid' : 'partial'}</div>`
                    : `<span style="color:#475569;font-size:0.82rem;">—</span>`
                }
            </td>
            <td style="padding:13px 16px;text-align:right;">
                <div style="font-weight:700;font-size:0.95rem;color:#3b82f6;">₹${paidThisMonth.toLocaleString('en-IN')}</div>
                <div style="font-size:0.7rem;color:#64748b;margin-top:2px;">${daysWorkedMonth} day${daysWorkedMonth !== 1 ? 's' : ''} worked</div>
            </td>
            <td style="padding:13px 16px;text-align:right;">${stillToPayCell}</td>
            <td style="padding:13px 10px;text-align:center;">
                <div style="display:flex;flex-direction:column;gap:5px;align-items:center;">
                    <button onclick="window.viewEmployeeLedger('${emp.id}')"
                        style="background:rgba(255,255,255,0.05);color:#94a3b8;border:1px solid rgba(255,255,255,0.1);border-radius:6px;padding:5px 10px;font-size:0.75rem;cursor:pointer;font-family:inherit;white-space:nowrap; display:flex; align-items:center; gap:4px;">
                        <i data-lucide="book-open" style="width:12px;"></i> Ledger
                    </button>
                    <button onclick="window.removeEmployee('${emp.id}')"
                        style="background:transparent;color:#475569;border:none;font-size:0.75rem;cursor:pointer;font-family:inherit;padding:3px; display:flex; align-items:center; gap:4px;"
                        onmouseover="this.style.color='#ef4444'" onmouseout="this.style.color='#475569'"><i data-lucide="user-x" style="width:12px;"></i> Remove</button>
                </div>
            </td>
        </tr>`;
    }).join('');

    body.innerHTML = rows;

    if (summary) {
        summary.innerHTML = `
            ${pill('users', `${emps.length} Employees`, '#3b82f6')}
            ${pill('check-circle', `${loggedToday}/${emps.length} Logged Today`, '#10b981')}
            ${pill('calendar', `₹${totalPaidMonthAll.toLocaleString('en-IN')} Paid This Month`, '#8b5cf6')}
            ${pill('info', `₹${totalPendingAll.toLocaleString('en-IN')} Dues Pending`, totalPendingAll > 0 ? '#ef4444' : '#10b981')}
        `;
    }

    if (window.lucide) window.lucide.createIcons();
}

// ─── Ledger Modal ─────────────────────────────────────────────────────────────
window.viewEmployeeLedger = (empId) => {
    const emps = JSON.parse(localStorage.getItem('mj_employees') || '[]');
    const logs = JSON.parse(localStorage.getItem('mj_emp_ledger') || '[]');
    const emp  = emps.find(e => e.id === empId);
    if (!emp) return;

    const nameEl = document.getElementById('modal-emp-name');
    nameEl.innerHTML = `Ledger — <span style="color:#10b981">${emp.name}</span>`;
    nameEl.dataset.empId = empId;

    const empLogs = logs.filter(l => l.empId === empId).sort((a, b) => b.timestamp - a.timestamp);
    const tbody = document.getElementById('modal-history-body');

    if (empLogs.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="empty-state">No records yet.</td></tr>';
    } else {
        let bal = 0;
        const asc = [...empLogs].reverse();
        asc.forEach(l => { bal += (l.earned - l.paid); l.balance = bal; });
        tbody.innerHTML = asc.reverse().map(l => `
            <tr>
                <td>${l.dateStr}</td>
                <td><span class="badge ${l.type==='WORKED' ? 'badge-warning' : 'badge-success'}">${l.type}</span></td>
                <td style="color:#fbbf24;text-align:right">${l.earned > 0 ? window.formatCurrency(l.earned) : '—'}</td>
                <td style="color:#34d399;text-align:right">${l.paid > 0 ? window.formatCurrency(l.paid) : '—'}</td>
                <td style="font-weight:700;text-align:right;color:${l.balance > 0 ? '#ef4444' : '#94a3b8'}">${window.formatCurrency(l.balance)}</td>
                <td style="text-align:center;">
                    <button onclick="window.deleteLogEntry(${l.id},'${empId}')"
                        title="Delete entry"
                        style="background:transparent;border:none;color:#475569;font-size:0.9rem;cursor:pointer;padding:3px 5px;border-radius:5px; display:flex; align-items:center; justify-content:center;"
                        onmouseover="this.style.color='#ef4444';this.style.background='rgba(239,68,68,0.1)'"
                        onmouseout="this.style.color='#475569';this.style.background='transparent'"><i data-lucide="trash-2" style="width:14px;"></i></button>
                </td>
            </tr>`).join('');
    }

    document.getElementById('salary-modal').style.display = 'flex';
    if (window.lucide) window.lucide.createIcons();
};

// ─── Toast ────────────────────────────────────────────────────────────────────
function showToast(msg, type = 'info') {
    let t = document.getElementById('emp-toast');
    if (!t) {
        t = document.createElement('div');
        t.id = 'emp-toast';
        t.style.cssText = 'position:fixed;bottom:26px;right:26px;z-index:9999;padding:11px 18px;border-radius:10px;font-size:0.86rem;font-weight:600;font-family:inherit;opacity:0;transform:translateY(8px);transition:opacity 0.25s,transform 0.25s;display:flex;align-items:center;gap:8px;box-shadow:0 6px 20px rgba(0,0,0,0.35);max-width:300px;';
        document.body.appendChild(t);
    }
    const s = {
        success: ['rgba(16,185,129,0.15)', 'rgba(16,185,129,0.3)', '#34d399', '✅'],
        error:   ['rgba(239,68,68,0.15)',  'rgba(239,68,68,0.3)',  '#f87171', '❌'],
        info:    ['rgba(59,130,246,0.15)', 'rgba(59,130,246,0.3)', '#93c5fd', 'ℹ️'],
    }[type];
    t.style.background = s[0]; t.style.border = `1px solid ${s[1]}`; t.style.color = s[2];
    t.innerHTML = `<span>${s[3]}</span><span>${msg}</span>`;
    t.style.opacity = '1'; t.style.transform = 'translateY(0)';
    clearTimeout(t._timer);
    t._timer = setTimeout(() => { t.style.opacity='0'; t.style.transform='translateY(8px)'; }, 2800);
}

// Legacy alias
window.clearPending = (empId, pending) => window.payDues(empId, pending);

document.addEventListener('DOMContentLoaded', () => {
    initEmployees();
    if (window.lucide) window.lucide.createIcons();
});
