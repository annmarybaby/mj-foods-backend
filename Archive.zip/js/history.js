// History View Module
window.initHistory = function() {
    const historyView = document.getElementById('view-history');
    if (!historyView) return;
    
    // Calculate Stats
    const sales = JSON.parse(localStorage.getItem('mj_sales') || '[]');

    // Shallow copy and reverse to show newest first
    const sortedSales = [...sales].reverse();

    const historyHtml = sortedSales.map(s => `
        <div style="background: rgba(255,255,255,0.03); padding: 15px 20px; border-radius: 12px; margin-bottom: 15px; border: 1px solid var(--border-color);">
            <div class="flex-between">
                <div>
                    <strong style="font-size: 1.1rem;">${s.shop || 'Walk-in Customer'}</strong>
                    <div style="font-size: 0.85rem; color: var(--text-muted); margin-top: 6px;">
                        ${new Date(s.timestamp).toLocaleDateString('en-IN')} - ${new Date(s.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                    </div>
                </div>
                <div style="display:flex; align-items:center; gap: 15px;">
                    <div style="text-align: right">
                        <div style="font-weight: 700; font-size: 1.2rem;">${window.formatCurrency(s.total)}</div>
                        <span class="badge ${s.status === 'Paid' ? 'badge-success' : 'badge-warning'}" style="margin-top: 5px; display: inline-block;">${s.status}</span>
                    </div>
                    ${s.status === 'Pending' ? 
                        `<button onclick="window.markInvoicePaid(${s.timestamp})" style="background: rgba(16, 185, 129, 0.1); border: 1px solid rgba(16, 185, 129, 0.2); color: var(--accent-emerald); border-radius: 8px; padding: 0 10px; height: 36px; cursor:pointer; font-size: 0.8rem; font-weight: 600;" title="Mark as Paid">✓ PAID</button>` : 
                        `<button onclick="window.markInvoiceUnpaid(${s.timestamp})" style="background: rgba(245, 158, 11, 0.1); border: 1px solid rgba(245, 158, 11, 0.2); color: var(--accent-orange); border-radius: 8px; padding: 0 10px; height: 36px; cursor:pointer; font-size: 0.8rem; font-weight: 600;" title="Revert to Unpaid">↺ UNPAID</button>`}
                    <button onclick="window.sharePastInvoicePDF(${s.timestamp})" style="background: rgba(18, 140, 126, 0.1); border: 1px solid rgba(18, 140, 126, 0.2); color: #25D366; border-radius: 8px; width: 36px; height: 36px; display:flex; align-items:center; justify-content:center; cursor:pointer;" title="Share PDF via WhatsApp">📄</button>
                    <button onclick="window.deleteInvoice(${s.timestamp})" style="background: rgba(239, 68, 68, 0.1); border: 1px solid rgba(239, 68, 68, 0.2); color: var(--accent-danger); border-radius: 8px; width: 36px; height: 36px; display:flex; align-items:center; justify-content:center; cursor:pointer;" title="Delete Invoice">✖</button>
                </div>
            </div>
            ${s.items && s.items.length > 0 ? `
            <details style="margin-top: 15px; border-top: 1px solid rgba(255,255,255,0.05); padding-top: 15px;">
                <summary style="cursor: pointer; color: var(--accent-blue); font-size: 0.9rem; font-weight: 500; outline: none; transition: color 0.2s;">View Full Details (${s.items.length} items)</summary>
                <div style="margin-top: 12px; background: rgba(0,0,0,0.2); padding: 10px 15px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.03);">
                    <table style="width: 100%; font-size: 0.85rem; border-collapse: collapse;">
                        <thead>
                            <tr style="color: var(--text-muted); text-transform: uppercase; font-size: 0.75rem;">
                                <th style="text-align: left; padding: 6px 4px; border-bottom: 1px solid rgba(255,255,255,0.05);">Item</th>
                                <th style="text-align: center; padding: 6px 4px; border-bottom: 1px solid rgba(255,255,255,0.05);">Qty</th>
                                <th style="text-align: right; padding: 6px 4px; border-bottom: 1px solid rgba(255,255,255,0.05);">Price</th>
                                <th style="text-align: right; padding: 6px 4px; border-bottom: 1px solid rgba(255,255,255,0.05);">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${s.items.map(item => `
                                <tr>
                                    <td style="padding: 8px 4px; border-bottom: 1px solid rgba(255,255,255,0.02); color: #f8fafc;">${item.name}</td>
                                    <td style="text-align: center; padding: 8px 4px; border-bottom: 1px solid rgba(255,255,255,0.02); color: #cbd5e1;">${item.qty}</td>
                                    <td style="text-align: right; padding: 8px 4px; border-bottom: 1px solid rgba(255,255,255,0.02); color: #cbd5e1;">${window.formatCurrency(item.price)}</td>
                                    <td style="text-align: right; padding: 8px 4px; border-bottom: 1px solid rgba(255,255,255,0.02); color: #f8fafc; font-weight: 600;">${window.formatCurrency(item.total)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </div>
            </details>
            ` : ''}
        </div>
    `).join('') || '<div class="empty-state">No sales history available.</div>';

    historyView.innerHTML = `
        <div class="card" style="height: calc(100vh - 120px); border-top: 4px solid var(--accent-blue);">
            <div class="flex-between mb-4" style="padding-bottom: 15px; border-bottom: 1px solid var(--border-color);">
                <h3 style="margin: 0; color: var(--text-primary); font-size: 1.3rem;">Complete Order History</h3>
                <span class="badge badge-success" style="font-size: 0.8rem; padding: 6px 14px;">Total Orders: ${sales.length}</span>
            </div>
            <div style="height: calc(100% - 60px); overflow-y: auto; padding-right: 15px;">
                ${historyHtml}
            </div>
        </div>
    `;
};

window.sharePastInvoicePDF = async (timestamp) => {
    const sales = JSON.parse(localStorage.getItem('mj_sales') || '[]');
    const sale = sales.find(s => s.timestamp === timestamp);
    if (!sale || !sale.items) return alert("Invoice details not found!");
    
    const shop = sale.shop || "Walk-in Customer";
    const grandTotal = window.formatCurrency(sale.total);
    const saleDate = new Date(sale.timestamp);
    
    let itemsHtml = sale.items.map(item => `
        <tr style="border-bottom: 1px solid #ddd;">
            <td style="padding: 12px 0;">${item.name}</td>
            <td style="padding: 12px 0; text-align: center;">${item.qty}</td>
            <td style="padding: 12px 0; text-align: right;">${window.formatCurrency(item.price)}</td>
            <td style="padding: 12px 0; text-align: right; font-weight: bold;">${window.formatCurrency(item.total)}</td>
        </tr>
    `).join('');

    const receiptDiv = document.getElementById('print-receipt');
    receiptDiv.innerHTML = `
        <div style="font-family: 'Outfit', Arial, sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; color: #111; background: #fff;">
            <div style="display: flex; align-items: center; justify-content: center; gap: 30px; border-bottom: 3px solid #111; padding-bottom: 25px; margin-bottom: 30px;">
                <img src="assets/logo.jpeg" style="width: 100px; height: 100px; object-fit: cover; border-radius: 50%; border: 3px solid #333;" onerror="this.style.display='none';">
                <div style="text-align: left;">
                    <h1 style="margin: 0; font-size: 2.8rem; text-transform: uppercase; letter-spacing: 2px; color: #111;">MJ Foods</h1>
                    <h2 style="margin: 5px 0 5px 0; font-size: 1.3rem; color: #444; letter-spacing: 1px;">MJ Enterprises</h2>
                    <p style="margin: 2px 0; font-size: 1rem; color: #555;">19/241 Kavaraparambu, Airport Road, Angamaly-683572</p>
                    <p style="margin: 2px 0; font-size: 1rem; color: #555;"><strong>FSSAI:</strong> 21323180000729  |  <strong>Phone:</strong> +91 9495691397, +91 8282821201</p>
                </div>
            </div>
            
            <div style="display: flex; justify-content: space-between; align-items: stretch; margin-bottom: 35px; background: #f8f9fa; padding: 20px; border-radius: 12px; border: 1px solid #e9ecef;">
                <div>
                    <p style="margin: 0 0 5px 0; color: #666; font-size: 0.9rem; text-transform: uppercase; font-weight: bold;">Billed To</p>
                    <h3 style="margin: 0; font-size: 1.4rem; color: #222;">${shop}</h3>
                </div>
                <div style="text-align: right; border-left: 2px solid #dee2e6; padding-left: 20px;">
                    <p style="margin: 0 0 5px 0; color: #666; font-size: 0.9rem; text-transform: uppercase; font-weight: bold;">Invoice Date & Time</p>
                    <h3 style="margin: 0; font-size: 1.2rem; color: #222;">${saleDate.toLocaleDateString('en-IN')}</h3>
                    <p style="margin: 4px 0 0 0; color: #555; font-size: 1rem;">${saleDate.toLocaleTimeString('en-IN', {hour: '2-digit', minute: '2-digit'})}</p>
                </div>
            </div>

            <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px;">
                <thead>
                    <tr style="background: #111; color: #fff;">
                        <th style="padding: 15px; text-align: left; border-radius: 8px 0 0 0; font-size: 1.05rem;">Item Description</th>
                        <th style="padding: 15px; text-align: center; font-size: 1.05rem;">Qty</th>
                        <th style="padding: 15px; text-align: right; font-size: 1.05rem;">Price</th>
                        <th style="padding: 15px; text-align: right; border-radius: 0 8px 0 0; font-size: 1.05rem;">Amount</th>
                    </tr>
                </thead>
                <tbody>
                    ${itemsHtml}
                </tbody>
            </table>

            <div style="display: flex; justify-content: flex-end; padding-top: 15px;">
                <div style="width: 350px; background: #fdfdfd; border: 2px solid #111; border-radius: 12px; padding: 20px;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; border-bottom: 1px solid #ddd; padding-bottom: 12px;">
                        <span style="font-size: 1.15rem; color: #555; text-transform: uppercase;">Subtotal</span>
                        <span style="font-size: 1.15rem; color: #222; font-weight: bold;">${grandTotal}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-size: 1.4rem; color: #111; font-weight: bold; text-transform: uppercase;">Grand Total</span>
                        <span style="font-size: 2.2rem; color: #111; font-weight: 900;">${grandTotal}</span>
                    </div>
                </div>
            </div>
            
            <div style="text-align: center; margin-top: 50px; color: #666; font-size: 1.05rem; border-top: 2px dashed #bbb; padding-top: 25px;">
                <p style="margin: 0 0 5px 0; font-weight: bold; color: #333; font-size: 1.2rem;">Thank you for your business!</p>
                <p style="margin: 0;">We hope to see you again soon.</p>
            </div>
        </div>
    `;

    const originalDisplay = receiptDiv.style.display;
    const originalPos = receiptDiv.style.position;
    const originalLeft = receiptDiv.style.left;
    const originalTop = receiptDiv.style.top;
    
    receiptDiv.style.display = 'block';
    receiptDiv.style.position = 'absolute';
    receiptDiv.style.left = '-9999px';
    receiptDiv.style.top = '-9999px';

    const opt = {
        margin:       0.5,
        filename:     `Invoice_${shop.replace(/[^a-zA-Z0-9]/g, '_')}_${timestamp}.pdf`,
        image:        { type: 'jpeg', quality: 0.98 },
        html2canvas:  { scale: 2, useCORS: true },
        jsPDF:        { unit: 'in', format: 'a4', orientation: 'portrait' }
    };

    try {
        const pdfBlob = await html2pdf().set(opt).from(receiptDiv).output('blob');
        
        receiptDiv.style.display = originalDisplay;
        receiptDiv.style.position = originalPos;
        receiptDiv.style.left = originalLeft;
        receiptDiv.style.top = originalTop;

        const file = new File([pdfBlob], opt.filename, { type: 'application/pdf' });
        
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
            await navigator.share({
                title: 'Invoice from MJ Foods',
                text: 'Here is your invoice from MJ Foods.',
                files: [file]
            });
        } else {
            alert("Direct PDF sharing is not fully supported on your browser. The PDF will be downloaded so you can share it manually on WhatsApp.");
            html2pdf().set(opt).from(receiptDiv).save();
        }
    } catch (err) {
        console.error('Error sharing past PDF:', err);
        receiptDiv.style.display = originalDisplay;
        receiptDiv.style.position = originalPos;
        receiptDiv.style.left = originalLeft;
        receiptDiv.style.top = originalTop;
        alert('An error occurred while generating or sharing the PDF.');
    }
};
