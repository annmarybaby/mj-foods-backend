// ═══════════════════════════════════════════════════════════════════
//  BILLING MODULE  — with Airport / Town shop categories
// ═══════════════════════════════════════════════════════════════════

const menu = [
    { n: "Carrot cake piece", p: 10 }, { n: "Parippuvada", p: 7 }, { n: "Uzhunnuvada", p: 9 },
    { n: "Bonda", p: 7 }, { n: "Sabolavada", p: 7 }, { n: "Sugiyan", p: 9 },
    { n: "Ella Ada", p: 10 }, { n: "Chi. Burger", p: 35 }, { n: "Veg. Burger", p: 28 },
    { n: "Chi. Sandwich", p: 28 }, { n: "Veg. Sandwich", p: 20 }, { n: "Unnakai", p: 14 },
    { n: "Erachi Pathiri", p: 15 }, { n: "Malabar Roll", p: 20 }, { n: "Egg Puffs", p: 15 },
    { n: "Veg. Puffs", p: 11 }, { n: "Chicken Puffs", p: 18 }, { n: "Banana Puffs", p: 14 },
    { n: "Chi. Cutlet", p: 15 }, { n: "Veg. Cutlet", p: 12 }, { n: "Chi. Roll", p: 16 },
    { n: "Veg. Roll", p: 12 }, { n: "Thalassery Roll", p: 16 }, { n: "Chicken Samosa", p: 10 },
    { n: "Elanchi", p: 13 }, { n: "Kaipola (8 piece)", p: 180 }, { n: "Chatti Pathiri (8 piece)", p: 200 },
    { n: "Bun Maska", p: 20 }
];
menu.sort((a, b) => a.n.localeCompare(b.n));

// ── Default airport shop names ──────────────────────────────────────────────
const DEFAULT_AIRPORT_SHOPS = [
    'Domestic', 'International', '0484', 'Gallery',
    'Cargo', 'Casino', 'Saravanabhavan', 'Achayi', 'Cafe 24'
];

// ── Migrate / initialise shop data ──────────────────────────────────────────
function getShops() {
    let shops = JSON.parse(localStorage.getItem('mj_shops_v2') || 'null');
    if (!shops) {
        // First run — migrate old flat list + seed defaults
        const oldList = JSON.parse(localStorage.getItem('mj_customers') || '[]');
        const airportSet = new Set(DEFAULT_AIRPORT_SHOPS.map(s => s.toLowerCase()));
        shops = { airport: [...DEFAULT_AIRPORT_SHOPS], town: [] };
        oldList.forEach(name => {
            if (!airportSet.has(name.toLowerCase()) && !shops.town.includes(name)) {
                shops.town.push(name);
            }
        });
        saveShops(shops);
    }
    return shops;
}
function saveShops(shops) {
    localStorage.setItem('mj_shops_v2', JSON.stringify(shops));
}

let currentItems = [];

// ── initBilling ─────────────────────────────────────────────────────────────
function initBilling() {
    const shops = getShops();
    const posGridHtml = menu.map((item, i) => `
        <button class="pos-item-btn" onclick="window.quickAddItem(${i})">
            <span class="item-name">${item.n}</span>
            <span class="item-price">${window.formatCurrency(item.p)}</span>
        </button>
    `).join('');

    // Build grouped datalist options
    const airportOpts = shops.airport.map(n => `<option value="${n}">`).join('');
    const townOpts    = shops.town.map(n => `<option value="${n}">`).join('');

    document.getElementById('view-billing').innerHTML = `

        <!-- ══ SHOP SELECTOR BAR ═══════════════════════════════════════ -->
        <div class="card mb-4" style="padding:0;overflow:hidden;">
            <!-- Tabs -->
            <div style="display:flex;border-bottom:1px solid rgba(255,255,255,0.07);">
                <button id="tab-airport" onclick="window.switchShopTab('airport')"
                    style="flex:1;padding:13px;font-size:0.82rem;font-weight:700;letter-spacing:0.5px;text-transform:uppercase;cursor:pointer;font-family:inherit;border:none;border-bottom:3px solid #3b82f6;background:rgba(59,130,246,0.08);color:#93c5fd; display:flex; align-items:center; justify-content:center; gap:6px;">
                    <i data-lucide="plane" style="width:14px;"></i> Airport Shops
                </button>
                <button id="tab-town" onclick="window.switchShopTab('town')"
                    style="flex:1;padding:13px;font-size:0.82rem;font-weight:700;letter-spacing:0.5px;text-transform:uppercase;cursor:pointer;font-family:inherit;border:none;border-bottom:3px solid transparent;background:transparent;color:#64748b; display:flex; align-items:center; justify-content:center; gap:6px;">
                    <i data-lucide="store" style="width:14px;"></i> Town Shops
                </button>
                <button id="tab-manage" onclick="window.switchShopTab('manage')"
                    style="flex:1;padding:13px;font-size:0.82rem;font-weight:700;letter-spacing:0.5px;text-transform:uppercase;cursor:pointer;font-family:inherit;border:none;border-bottom:3px solid transparent;background:transparent;color:#64748b; display:flex; align-items:center; justify-content:center; gap:6px;">
                    <i data-lucide="settings" style="width:14px;"></i> Manage Shops
                </button>
            </div>

            <!-- Airport Shops Panel -->
            <div id="panel-airport" style="padding:16px 20px;">
                <div id="airport-chip-list" style="display:flex;flex-wrap:wrap;gap:8px;"></div>
            </div>

            <!-- Town Shops Panel -->
            <div id="panel-town" style="display:none;padding:16px 20px;">
                <div id="town-chip-list" style="display:flex;flex-wrap:wrap;gap:8px;"></div>
            </div>

            <!-- Manage Shops Panel -->
            <div id="panel-manage" style="display:none;padding:20px;">
                <div class="manage-shops-grid">

                    <!-- Airport list -->
                    <div>
                        <div style="font-size:0.75rem;font-weight:700;color:#3b82f6;text-transform:uppercase;letter-spacing:1px;margin-bottom:10px; display:flex; align-items:center; gap:5px;"><i data-lucide="plane" style="width:12px;"></i> Airport Shops</div>
                        <div id="manage-airport-list"></div>
                        <div style="display:flex;gap:6px;margin-top:10px;">
                            <input id="new-airport-name" placeholder="New airport shop name" style="flex:1;padding:9px 12px;margin:0;">
                            <button onclick="window.addShop('airport')"
                                style="background:#3b82f6;color:white;border:none;border-radius:9px;padding:9px 14px;font-weight:600;cursor:pointer;font-family:inherit;white-space:nowrap;">+ Add</button>
                        </div>
                    </div>

                    <!-- Town list -->
                    <div>
                        <div style="font-size:0.75rem;font-weight:700;color:#10b981;text-transform:uppercase;letter-spacing:1px;margin-bottom:10px; display:flex; align-items:center; gap:5px;"><i data-lucide="store" style="width:12px;"></i> Town Shops</div>
                        <div id="manage-town-list"></div>
                        <div style="display:flex;gap:6px;margin-top:10px;">
                            <input id="new-town-name" placeholder="New town shop name" style="flex:1;padding:9px 12px;margin:0;">
                            <button onclick="window.addShop('town')"
                                style="background:#10b981;color:white;border:none;border-radius:9px;padding:9px 14px;font-weight:600;cursor:pointer;font-family:inherit;white-space:nowrap;">+ Add</button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Selected shop display + manual input -->
            <div style="padding:12px 18px;background:rgba(0,0,0,0.15);border-top:1px solid rgba(255,255,255,0.06);display:flex;align-items:center;gap:10px;">
                <span style="font-size:0.78rem;color:#64748b;white-space:nowrap;">Billing to:</span>
                <input type="text" id="shop-name" list="customer-datalist"
                    placeholder="Select a shop above, or type a name…"
                    style="flex:1;padding:10px 14px;font-size:0.95rem;margin:0;background:rgba(0,0,0,0.3);border-color:rgba(255,255,255,0.12);">
                <datalist id="customer-datalist">
                    ${airportOpts}${townOpts}
                </datalist>
            </div>
        </div>

        <!-- ══ POS + INVOICE ════════════════════════════════════════════ -->
        <div class="billing-main-grid">
            <!-- POS Grid -->
            <div class="card" style="padding:20px;background:rgba(0,0,0,0.15)">
                <div class="flex-between mb-4">
                    <h4 style="color:var(--text-muted);text-transform:uppercase;font-size:0.85rem;letter-spacing:1px;margin:0;">Quick Add Menu</h4>
                    <span class="badge badge-success" style="font-size:0.7rem;">Point of Sale</span>
                </div>
                <div style="margin-bottom:16px;">
                    <input type="text" id="menu-search" oninput="window.filterMenu(this.value)"
                        placeholder="🔍 Search item…"
                        style="width:100%;padding:12px 16px;border-radius:8px;border:1px solid rgba(255,255,255,0.1);background:rgba(0,0,0,0.3);color:white;font-size:0.95rem;outline:none;"
                        onfocus="this.style.borderColor='var(--accent-emerald)'"
                        onblur="this.style.borderColor='rgba(255,255,255,0.1)'">
                </div>
                <div class="pos-grid" id="pos-grid-container">${posGridHtml}</div>

                <div style="margin-top:25px;padding-top:20px;border-top:1px solid var(--border-color);">
                    <h4 style="color:var(--text-muted);text-transform:uppercase;font-size:0.85rem;letter-spacing:1px;margin:0 0 12px 0;">Add Custom Item</h4>
                    <div class="custom-item-grid">
                        <input type="text" id="custom-name" placeholder="Item Name" style="font-size:0.95rem;padding:12px;">
                        <input type="number" id="custom-price" placeholder="Price (₹)" style="font-size:0.95rem;padding:12px;">
                        <button class="btn btn-secondary" onclick="window.addCustomItem()" style="padding:12px 20px;font-size:1.2rem;">+</button>
                    </div>
                </div>
            </div>

            <!-- Invoice Panel -->
            <div class="card" style="border-top:4px solid var(--accent-blue);position:sticky;top:100px;padding:0;overflow:hidden;">
                <div style="padding:20px 20px 10px 20px;background:rgba(255,255,255,0.02);border-bottom:1px solid var(--border-color);">
                    <h3 style="margin:0;">Current Invoice</h3>
                </div>
                <div class="table-container" style="max-height:400px;overflow-y:auto;margin-top:0;border:none;border-radius:0;background:transparent;">
                    <table id="bill-table" style="font-size:0.9rem;">
                        <thead style="position:sticky;top:0;z-index:5;background:var(--bg-panel);backdrop-filter:var(--glass-blur);">
                            <tr>
                                <th style="padding-left:20px;">Item</th>
                                <th style="text-align:center;width:90px;">Qty</th>
                                <th style="text-align:right;padding-right:20px;">Total</th>
                            </tr>
                        </thead>
                        <tbody id="bill-body"><tr><td colspan="3" class="empty-state">No items added yet.<br><br>Click an item from the menu.</td></tr></tbody>
                    </table>
                </div>
                <div style="padding:20px;background:rgba(0,0,0,0.2);border-top:1px solid var(--border-color)">
                    <div class="flex-between mb-4">
                        <span style="color:var(--text-muted);font-size:0.9rem;text-transform:uppercase;font-weight:600;">Grand Total</span>
                        <h2 style="margin:0;font-size:2.2rem;color:var(--accent-emerald)" id="grand-total">₹0.00</h2>
                    </div>
                    <div style="display:flex;flex-direction:column;gap:12px;" class="no-print">
                        <button class="btn btn-warning" style="height:55px;font-size:1.15rem;width:100%;box-shadow:0 4px 20px rgba(245,158,11,0.2)" onclick="window.saveBill('Pending')"><i data-lucide="file-check-2" style="width:20px;"></i> Generate Invoice</button>
                        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px;">
                            <button class="btn btn-secondary" onclick="window.prepareAndPrint()" style="height:50px;font-size:0.95rem; flex-direction: column; gap: 4px;">
                                <i data-lucide="printer" style="width:18px;"></i> Print
                            </button>
                            <button class="btn btn-success" style="background:#25D366;color:white;height:50px;font-size:0.95rem;box-shadow:0 4px 15px rgba(37,211,102,0.2);border:none; flex-direction: column; gap: 4px;" onclick="window.sendWhatsApp()">
                                <i data-lucide="message-square" style="width:18px;"></i> WA Text
                            </button>
                            <button class="btn btn-primary" style="background:#128C7E;color:white;height:50px;font-size:0.95rem;box-shadow:0 4px 15px rgba(18,140,126,0.2);border:none; flex-direction: column; gap: 4px;" onclick="window.sharePDF()">
                                <i data-lucide="share-2" style="width:18px;"></i> Share PDF
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    renderShopChips();
    if (window.lucide) window.lucide.createIcons();
}

// ── Tab switching ────────────────────────────────────────────────────────────
window.switchShopTab = (tab) => {
    ['airport', 'town', 'manage'].forEach(t => {
        const panel = document.getElementById(`panel-${t}`);
        const btn   = document.getElementById(`tab-${t}`);
        if (!panel || !btn) return;
        const active = t === tab;
        panel.style.display = active ? '' : 'none';
        if (active) {
            btn.style.borderBottomColor = t === 'airport' ? '#3b82f6' : t === 'town' ? '#10b981' : '#f59e0b';
            btn.style.background = t === 'airport' ? 'rgba(59,130,246,0.08)' : t === 'town' ? 'rgba(16,185,129,0.08)' : 'rgba(245,158,11,0.08)';
            btn.style.color = t === 'airport' ? '#93c5fd' : t === 'town' ? '#34d399' : '#fbbf24';
        } else {
            btn.style.borderBottomColor = 'transparent';
            btn.style.background = 'transparent';
            btn.style.color = '#64748b';
        }
    });
    if (tab === 'manage') renderManageLists();
};

// ── Render chips ─────────────────────────────────────────────────────────────
function renderShopChips() {
    const shops = getShops();
    const makeChip = (name, color) =>
        `<button onclick="window.selectShop('${name.replace(/'/g,"\\'")}',this)"
            style="background:rgba(${color},0.1);color:rgb(${color});border:1px solid rgba(${color},0.25);border-radius:20px;padding:7px 16px;font-size:0.85rem;font-weight:600;cursor:pointer;font-family:inherit;transition:all 0.15s;"
            onmouseover="this.style.background='rgba(${color},0.22)'"
            onmouseout="if(!this.dataset.active)this.style.background='rgba(${color},0.1)'">${name}</button>`;

    const airportEl = document.getElementById('airport-chip-list');
    const townEl    = document.getElementById('town-chip-list');
    if (airportEl) airportEl.innerHTML = shops.airport.length
        ? shops.airport.map(n => makeChip(n, '59,130,246')).join('')
        : '<span style="color:#64748b;font-size:0.85rem;">No airport shops added yet.</span>';
    if (townEl) townEl.innerHTML = shops.town.length
        ? shops.town.map(n => makeChip(n, '16,185,129')).join('')
        : '<span style="color:#64748b;font-size:0.85rem;">No town shops added yet.</span>';
}

// ── Select shop chip ─────────────────────────────────────────────────────────
window.selectShop = (name, btn) => {
    // Deselect all chips
    document.querySelectorAll('#airport-chip-list button, #town-chip-list button').forEach(b => {
        delete b.dataset.active;
        b.style.outline = 'none';
    });
    btn.dataset.active = '1';
    btn.style.outline = '2px solid currentColor';
    const input = document.getElementById('shop-name');
    if (input) input.value = name;
};

// ── Manage lists ─────────────────────────────────────────────────────────────
function renderManageLists() {
    const shops = getShops();
    ['airport', 'town'].forEach(type => {
        const color = type === 'airport' ? '#3b82f6' : '#10b981';
        const el = document.getElementById(`manage-${type}-list`);
        if (!el) return;
        el.innerHTML = shops[type].length === 0
            ? `<p style="color:#64748b;font-size:0.82rem;font-style:italic;">No shops yet.</p>`
            : shops[type].map((name, idx) => `
                <div id="shop-row-${type}-${idx}" style="display:flex;align-items:center;gap:6px;margin-bottom:6px;">
                    <span style="flex:1;font-size:0.88rem;color:#f1f5f9;">${name}</span>
                    <button onclick="window.beginEditShop('${type}',${idx})"
                        style="background:rgba(59,130,246,0.1);color:#93c5fd;border:1px solid rgba(59,130,246,0.2);border-radius:6px;padding:4px 10px;font-size:0.75rem;font-weight:600;cursor:pointer;font-family:inherit; display:flex; align-items:center; gap:4px;"><i data-lucide="edit-3" style="width:12px;"></i> Edit</button>
                    <button onclick="window.deleteShop('${type}',${idx})"
                        style="background:rgba(239,68,68,0.08);color:#f87171;border:1px solid rgba(239,68,68,0.2);border-radius:6px;padding:4px 8px;font-size:0.75rem;cursor:pointer;font-family:inherit; display:flex; align-items:center; justify-content:center;"
                        onmouseover="this.style.background='rgba(239,68,68,0.22)'"
                        onmouseout="this.style.background='rgba(239,68,68,0.08)'"><i data-lucide="trash-2" style="width:14px;"></i></button>
                </div>
            `).join('');
    });
    if (window.lucide) window.lucide.createIcons();
}

// ── Add shop ─────────────────────────────────────────────────────────────────
window.addShop = (type) => {
    const input = document.getElementById(`new-${type}-name`);
    const name  = input ? input.value.trim() : '';
    if (!name) return showBillToast('Enter a shop name.', 'error');
    const shops = getShops();
    const allNames = [...shops.airport, ...shops.town].map(s => s.toLowerCase());
    if (allNames.includes(name.toLowerCase())) return showBillToast('Shop already exists.', 'error');
    shops[type].push(name);
    saveShops(shops);
    input.value = '';
    renderShopChips();
    renderManageLists();
    showBillToast(`"${name}" added to ${type} shops!`, 'success');
};

// ── Edit shop ─────────────────────────────────────────────────────────────────
window.beginEditShop = (type, idx) => {
    const shops = getShops();
    const oldName = shops[type][idx];
    const row = document.getElementById(`shop-row-${type}-${idx}`);
    if (!row) return;
    row.innerHTML = `
        <input id="edit-shop-input" value="${oldName}"
            style="flex:1;padding:6px 10px;background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.15);border-radius:7px;color:#f8fafc;font-size:0.85rem;font-family:inherit;">
        <button onclick="window.confirmEditShop('${type}',${idx})"
            style="background:#10b981;color:white;border:none;border-radius:6px;padding:5px 12px;font-size:0.78rem;font-weight:600;cursor:pointer;font-family:inherit;">✓ Save</button>
        <button onclick="renderManageLists()"
            style="background:rgba(255,255,255,0.07);color:#94a3b8;border:1px solid rgba(255,255,255,0.1);border-radius:6px;padding:5px 9px;font-size:0.78rem;cursor:pointer;font-family:inherit;">✕</button>
    `;
    document.getElementById('edit-shop-input').focus();
};

window.confirmEditShop = (type, idx) => {
    const newName = (document.getElementById('edit-shop-input')?.value || '').trim();
    if (!newName) return showBillToast('Name cannot be empty.', 'error');
    const shops = getShops();
    const allNames = [...shops.airport, ...shops.town]
        .filter((_, i) => !(type === 'airport' ? i === idx : shops.airport.length + i === idx))
        .map(s => s.toLowerCase());
    if (allNames.includes(newName.toLowerCase())) return showBillToast('A shop with that name already exists.', 'error');
    const oldName = shops[type][idx];
    shops[type][idx] = newName;
    saveShops(shops);
    renderShopChips();
    renderManageLists();
    // update billing input if it was showing old name
    const shopInput = document.getElementById('shop-name');
    if (shopInput && shopInput.value === oldName) shopInput.value = newName;
    showBillToast(`Renamed to "${newName}".`, 'success');
};

// ── Delete shop ───────────────────────────────────────────────────────────────
window.deleteShop = (type, idx) => {
    const shops = getShops();
    const name  = shops[type][idx];
    if (!confirm(`Remove "${name}" from ${type} shops?`)) return;
    shops[type].splice(idx, 1);
    saveShops(shops);
    renderShopChips();
    renderManageLists();
    showBillToast(`"${name}" removed.`, 'info');
};

// ── Menu filter ───────────────────────────────────────────────────────────────
window.filterMenu = (query) => {
    query = query.toLowerCase();
    document.querySelectorAll('#pos-grid-container .pos-item-btn').forEach(btn => {
        btn.style.display = btn.querySelector('.item-name').innerText.toLowerCase().includes(query) ? 'flex' : 'none';
    });
};

// ── POS item actions ──────────────────────────────────────────────────────────
window.quickAddItem = (idx) => {
    const item = menu[idx];
    const existing = currentItems.find(i => i.name === item.n);
    if (existing) {
        existing.qty++;
        existing.total = existing.qty * existing.price;
    } else {
        currentItems.push({ name: item.n, qty: 1, price: item.p, total: item.p });
    }
    renderBillingTable();
};

window.addCustomItem = () => {
    const name  = document.getElementById('custom-name').value.trim();
    const price = parseFloat(document.getElementById('custom-price').value);
    if (!name || isNaN(price) || price < 0) return showBillToast('Enter a valid item name and price.', 'error');
    const existing = currentItems.find(i => i.name === name);
    if (existing) { existing.qty++; existing.total = existing.qty * existing.price; }
    else currentItems.push({ name, qty: 1, price, total: price });
    renderBillingTable();
    document.getElementById('custom-name').value = '';
    document.getElementById('custom-price').value = '';
};

window.updateItemQty = (index, delta) => {
    currentItems[index].qty += delta;
    if (currentItems[index].qty <= 0) currentItems.splice(index, 1);
    else currentItems[index].total = currentItems[index].qty * currentItems[index].price;
    renderBillingTable();
};

window.setCustomItemQty = (index, value) => {
    let qty = parseInt(value);
    if (isNaN(qty) || qty <= 0) qty = 1;
    currentItems[index].qty = qty;
    currentItems[index].total = qty * currentItems[index].price;
    renderBillingTable();
};

function renderBillingTable() {
    const body = document.getElementById('bill-body');
    let grandTotal = 0;
    if (currentItems.length === 0) {
        body.innerHTML = '<tr><td colspan="3" class="empty-state" style="padding:40px 20px;">No items added yet.<br><br>Click an item from the menu.</td></tr>';
        document.getElementById('grand-total').textContent = '₹0.00';
        return;
    }
    body.innerHTML = currentItems.map((item, index) => {
        grandTotal += item.total;
        return `
            <tr>
                <td style="padding-left:20px;vertical-align:middle;">
                    <strong style="font-size:1.05rem;">${item.name}</strong><br>
                    <span style="font-size:0.8rem;color:var(--text-muted)">${window.formatCurrency(item.price)} each</span>
                </td>
                <td style="text-align:center;white-space:nowrap;vertical-align:middle;">
                    <div style="display:flex;align-items:center;justify-content:center;gap:6px;background:rgba(0,0,0,0.2);border-radius:8px;padding:4px;">
                        <button class="qty-btn" onclick="window.updateItemQty(${index},-1)">-</button>
                        <input type="number" value="${item.qty}" min="1" onchange="window.setCustomItemQty(${index},this.value)"
                            style="width:50px;text-align:center;padding:4px;border:1px solid rgba(255,255,255,0.1);border-radius:4px;background:rgba(0,0,0,0.3);color:white;display:inline-block;">
                        <button class="qty-btn" onclick="window.updateItemQty(${index},1)">+</button>
                    </div>
                </td>
                <td style="text-align:right;font-weight:600;padding-right:20px;vertical-align:middle;color:#fff;">${window.formatCurrency(item.total)}</td>
            </tr>`;
    }).join('');
    document.getElementById('grand-total').textContent = window.formatCurrency(grandTotal);
}

// ── Save / generate bill ──────────────────────────────────────────────────────
window.saveBill = (status) => {
    const shopInput = document.getElementById('shop-name').value.trim();
    const shop = shopInput || 'Walk-in Customer';
    const total = parseFloat(document.getElementById('grand-total').textContent.replace(/[₹,]/g, ''));
    if (!total || isNaN(total)) return showBillToast('Please add at least one item!', 'error');

    const sale = { shop, total, status, timestamp: Date.now(), items: currentItems };
    let history = JSON.parse(localStorage.getItem('mj_sales') || '[]');
    history.push(sale);
    localStorage.setItem('mj_sales', JSON.stringify(history));

    window.prepareAndPrint();
    currentItems = [];
    document.getElementById('shop-name').value = '';
    renderBillingTable();
    if (window.refreshDashboard) window.refreshDashboard();
};

// ── Legacy alias ──────────────────────────────────────────────────────────────
window.manuallyAddCustomer = () => {
    const name = document.getElementById('shop-name')?.value.trim();
    if (!name) return showBillToast('Type a shop name first.', 'error');
    const shops = getShops();
    const existing = [...shops.airport, ...shops.town].map(s => s.toLowerCase());
    if (existing.includes(name.toLowerCase())) return showBillToast('Already in the list.', 'info');
    shops.town.push(name);
    saveShops(shops);
    renderShopChips();
    showBillToast(`"${name}" added to Town shops.`, 'success');
};

// ── Print / receipt helpers (unchanged) ───────────────────────────────────────
window.prepareAndPrint = () => {
    const shop = document.getElementById('shop-name')?.value || 'Walk-in Customer';
    const grandTotal = document.getElementById('grand-total')?.textContent;
    if (currentItems.length === 0) return showBillToast('Nothing to print!', 'error');

    const itemsHtml = currentItems.map(item => `
        <tr style="border-bottom:1px solid #ddd;">
            <td style="padding:12px 0;">${item.name}</td>
            <td style="padding:12px 0;text-align:center;">${item.qty}</td>
            <td style="padding:12px 0;text-align:right;">${window.formatCurrency(item.price)}</td>
            <td style="padding:12px 0;text-align:right;font-weight:bold;">${window.formatCurrency(item.total)}</td>
        </tr>`).join('');

    document.getElementById('print-receipt').innerHTML = receiptHTML(shop, grandTotal, itemsHtml);
    setTimeout(() => window.print(), 100);
};

window.sendWhatsApp = () => {
    const shop = document.getElementById('shop-name')?.value || 'Walk-in Customer';
    if (currentItems.length === 0) return showBillToast('Add at least one item first!', 'error');
    const grandTotal = document.getElementById('grand-total').textContent;
    let text = `🏪 *MJ FOODS ENTERPRISES*\n📍 19/241 Kavaraparambu, Airport Road\n📍 Angamaly-683572\n📞 Ph: +91 9495691397, +91 8282821201\n🛡️ FSSAI: 21323180000729\n\n--------------------------------\n🧾 *INVOICE RECEIPT*\n--------------------------------\n👤 *Billed To:* ${shop}\n📅 *Date:* ${new Date().toLocaleDateString('en-IN')} ${new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'})}\n--------------------------------\n\n*Order Details:*\n`;
    currentItems.forEach(i => { text += `▫️ *${i.name}*\n   [ ${i.qty} x ${window.formatCurrency(i.price)} ]  ➡️  *${window.formatCurrency(i.total)}*\n\n`; });
    text += `--------------------------------\n💰 *GRAND TOTAL: ${grandTotal}*\n--------------------------------\n\n_Thank you for your business!_ 🍽️\n_Please visit again._`;
    window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text)}`, '_blank');
};

window.sharePDF = async () => {
    const shop = document.getElementById('shop-name')?.value || 'Walk-in Customer';
    const grandTotal = document.getElementById('grand-total')?.textContent;
    if (currentItems.length === 0) return showBillToast('Nothing to share!', 'error');
    const itemsHtml = currentItems.map(item => `
        <tr style="border-bottom:1px solid #ddd;">
            <td style="padding:12px 0;">${item.name}</td>
            <td style="padding:12px 0;text-align:center;">${item.qty}</td>
            <td style="padding:12px 0;text-align:right;">${window.formatCurrency(item.price)}</td>
            <td style="padding:12px 0;text-align:right;font-weight:bold;">${window.formatCurrency(item.total)}</td>
        </tr>`).join('');
    const receiptDiv = document.getElementById('print-receipt');
    receiptDiv.innerHTML = receiptHTML(shop, grandTotal, itemsHtml);
    const orig = { display: receiptDiv.style.display, position: receiptDiv.style.position, left: receiptDiv.style.left, top: receiptDiv.style.top };
    receiptDiv.style.display = 'block';
    receiptDiv.style.position = 'absolute';
    receiptDiv.style.left = '-9999px';
    receiptDiv.style.top  = '-9999px';
    const opt = { margin: 0.5, filename: `Invoice_${shop.replace(/[^a-zA-Z0-9]/g,'_')}_${Date.now()}.pdf`, image: { type:'jpeg', quality:0.98 }, html2canvas: { scale:2, useCORS:true }, jsPDF: { unit:'in', format:'a4', orientation:'portrait' } };
    try {
        const pdfBlob = await html2pdf().set(opt).from(receiptDiv).output('blob');
        Object.assign(receiptDiv.style, orig);
        const file = new File([pdfBlob], opt.filename, { type:'application/pdf' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) {
            await navigator.share({ title:'Invoice from MJ Foods', text:'Here is your invoice from MJ Foods.', files:[file] });
        } else {
            showBillToast('PDF sharing not supported — downloading instead.', 'info');
            html2pdf().set(opt).from(receiptDiv).save();
        }
    } catch (err) {
        Object.assign(receiptDiv.style, orig);
        showBillToast('Error generating PDF.', 'error');
    }
};

function receiptHTML(shop, grandTotal, itemsHtml) {
    return `<div style="font-family:'Outfit',Arial,sans-serif;padding:20px;max-width:800px;margin:0 auto;color:#111;">
        <div style="display:flex;align-items:center;justify-content:center;gap:30px;border-bottom:3px solid #111;padding-bottom:25px;margin-bottom:30px;">
            <img src="assets/logo.jpeg" style="width:100px;height:100px;object-fit:cover;border-radius:50%;border:3px solid #333;" onerror="this.style.display='none';">
            <div style="text-align:left;">
                <h1 style="margin:0;font-size:2.8rem;text-transform:uppercase;letter-spacing:2px;color:#111;">MJ Foods</h1>
                <h2 style="margin:5px 0;font-size:1.3rem;color:#444;">MJ Enterprises</h2>
                <p style="margin:2px 0;font-size:1rem;color:#555;">19/241 Kavaraparambu, Airport Road, Angamaly-683572</p>
                <p style="margin:2px 0;font-size:1rem;color:#555;"><strong>FSSAI:</strong> 21323180000729  |  <strong>Phone:</strong> +91 9495691397, +91 8282821201</p>
            </div>
        </div>
        <div style="display:flex;justify-content:space-between;margin-bottom:35px;background:#f8f9fa;padding:20px;border-radius:12px;border:1px solid #e9ecef;">
            <div><p style="margin:0 0 5px;color:#666;font-size:0.9rem;text-transform:uppercase;font-weight:bold;">Billed To</p><h3 style="margin:0;font-size:1.4rem;color:#222;">${shop}</h3></div>
            <div style="text-align:right;border-left:2px solid #dee2e6;padding-left:20px;">
                <p style="margin:0 0 5px;color:#666;font-size:0.9rem;text-transform:uppercase;font-weight:bold;">Invoice Date &amp; Time</p>
                <h3 style="margin:0;font-size:1.2rem;color:#222;">${new Date().toLocaleDateString('en-IN')}</h3>
                <p style="margin:4px 0 0;color:#555;font-size:1rem;">${new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'})}</p>
            </div>
        </div>
        <table style="width:100%;border-collapse:collapse;margin-bottom:30px;">
            <thead><tr style="background:#111;color:#fff;">
                <th style="padding:15px;text-align:left;border-radius:8px 0 0 0;">Item Description</th>
                <th style="padding:15px;text-align:center;">Qty</th>
                <th style="padding:15px;text-align:right;">Price</th>
                <th style="padding:15px;text-align:right;border-radius:0 8px 0 0;">Amount</th>
            </tr></thead>
            <tbody>${itemsHtml}</tbody>
        </table>
        <div style="display:flex;justify-content:flex-end;padding-top:15px;">
            <div style="width:350px;background:#fdfdfd;border:2px solid #111;border-radius:12px;padding:20px;">
                <div style="display:flex;justify-content:space-between;margin-bottom:12px;border-bottom:1px solid #ddd;padding-bottom:12px;">
                    <span style="font-size:1.15rem;color:#555;text-transform:uppercase;">Subtotal</span>
                    <span style="font-size:1.15rem;color:#222;font-weight:bold;">${grandTotal}</span>
                </div>
                <div style="display:flex;justify-content:space-between;">
                    <span style="font-size:1.4rem;color:#111;font-weight:bold;text-transform:uppercase;">Grand Total</span>
                    <span style="font-size:2.2rem;color:#111;font-weight:900;">${grandTotal}</span>
                </div>
            </div>
        </div>
        <div style="text-align:center;margin-top:50px;color:#666;font-size:1.05rem;border-top:2px dashed #bbb;padding-top:25px;">
            <p style="margin:0 0 5px;font-weight:bold;color:#333;font-size:1.2rem;">Thank you for your business!</p>
            <p style="margin:0;">We hope to see you again soon.</p>
        </div>
    </div>`;
}

// ── Toast ─────────────────────────────────────────────────────────────────────
function showBillToast(msg, type = 'info') {
    let t = document.getElementById('bill-toast');
    if (!t) {
        t = document.createElement('div');
        t.id = 'bill-toast';
        t.style.cssText = 'position:fixed;bottom:26px;right:26px;z-index:9999;padding:11px 18px;border-radius:10px;font-size:0.86rem;font-weight:600;font-family:inherit;opacity:0;transform:translateY(8px);transition:opacity 0.25s,transform 0.25s;display:flex;align-items:center;gap:8px;box-shadow:0 6px 20px rgba(0,0,0,0.35);max-width:320px;';
        document.body.appendChild(t);
    }
    const s = {
        success: ['rgba(16,185,129,0.15)','rgba(16,185,129,0.3)','#34d399','✅'],
        error:   ['rgba(239,68,68,0.15)', 'rgba(239,68,68,0.3)', '#f87171','❌'],
        info:    ['rgba(59,130,246,0.15)','rgba(59,130,246,0.3)','#93c5fd','ℹ️'],
    }[type];
    t.style.background = s[0]; t.style.border = `1px solid ${s[1]}`; t.style.color = s[2];
    t.innerHTML = `<span>${s[3]}</span><span>${msg}</span>`;
    t.style.opacity = '1'; t.style.transform = 'translateY(0)';
    clearTimeout(t._t);
    t._t = setTimeout(() => { t.style.opacity='0'; t.style.transform='translateY(8px)'; }, 2800);
}

document.addEventListener('DOMContentLoaded', initBilling);
