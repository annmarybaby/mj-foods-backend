let currentProfitPeriod = 'today';

window.refreshDashboard = function() {
    const dashboardView = document.getElementById('view-dashboard');

    // ── Data ──────────────────────────────────────────────────────────────────
    const sales      = JSON.parse(localStorage.getItem('mj_sales')       || '[]');
    const exps       = JSON.parse(localStorage.getItem('mj_expenses')     || '[]');
    const salaryLogs = JSON.parse(localStorage.getItem('mj_emp_ledger')   || '[]');
    const receipts   = JSON.parse(localStorage.getItem('mj_receipts')     || '[]');
    const now        = new Date();

    const isToday = ts => new Date(ts).toDateString() === now.toDateString();
    
    // Period logic
    const isInPeriod = (ts, period) => {
        const d = new Date(ts);
        if (period === 'today') return isToday(ts);
        if (period === 'week') {
            const weekAgo = new Date();
            weekAgo.setDate(now.getDate() - 7);
            return d >= weekAgo;
        }
        if (period === 'month') return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
        if (period === 'year') return d.getFullYear() === now.getFullYear();
        return false;
    };

    const periodSales = sales.filter(s => isInPeriod(s.timestamp, currentProfitPeriod)).reduce((a,c) => a + c.total, 0);
    const periodExps = exps.filter(e => isInPeriod(e.timestamp, currentProfitPeriod)).reduce((a,c) => a + c.amt, 0);
    const periodSalary = salaryLogs.filter(s => isInPeriod(s.timestamp, currentProfitPeriod)).reduce((a,c) => a + c.paid, 0);
    const periodProfit = periodSales - (periodExps + periodSalary);

    const todaySales = sales.filter(s => isToday(s.timestamp)).reduce((a,c) => a + c.total, 0);
    const pendingSales = sales.filter(s => s.status === 'Pending').reduce((a,c) => a + c.total, 0);

    const allOrders = sales.slice().reverse();
    const recentSalesHtml = allOrders.map((s, idx) => {
        const dateObj = new Date(s.timestamp);
        const dateStr = dateObj.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' });
        const timeStr = dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        const itemDetails = s.items ? s.items.map(it => `
            <div style="display:flex;justify-content:space-between;padding:4px 0;border-bottom:1px solid rgba(255,255,255,0.03);font-size:0.78rem;">
                <span style="color:#94a3b8;">${it.qty} × ${it.name}</span>
                <span style="font-weight:600;color:#fff;">${window.formatCurrency(it.total)}</span>
            </div>
        `).join('') : '<div style="color:#64748b;font-size:0.75rem;">No item details.</div>';

        return `
            <div style="background:rgba(255,255,255,0.03);padding:14px 18px;border-radius:12px;margin-bottom:12px;border:1px solid var(--border-color); overflow:hidden;" class="order-card-wrapper">
                <div class="flex-between">
                    <div style="flex:1;">
                        <div style="display:flex;align-items:center;gap:8px;">
                            <strong style="font-size:1.1rem;color:#f1f5f9;">${s.shop || 'Walk-in Customer'}</strong>
                            <span class="badge ${s.status==='Paid'?'badge-success':'badge-warning'}" style="font-size:0.65rem;">${s.status}</span>
                        </div>
                        <div style="font-size:0.78rem;color:var(--text-muted);margin-top:4px; display:flex; gap:10px;">
                            <span style="display:flex;align-items:center;gap:4px;"><i data-lucide="calendar" style="width:12px;"></i> ${dateStr}</span>
                            <span style="display:flex;align-items:center;gap:4px;"><i data-lucide="clock" style="width:12px;"></i> ${timeStr}</span>
                        </div>
                    </div>
                    <div style="text-align:right; margin-right:15px;">
                        <div style="font-weight:700;font-size:1.2rem;color:var(--accent-emerald);">${window.formatCurrency(s.total)}</div>
                        <button onclick="this.closest('.order-card-wrapper').querySelector('.order-details-drawer').classList.toggle('open')" 
                            style="background:none;border:none;color:var(--accent-blue);font-size:0.75rem;font-weight:600;cursor:pointer;padding:4px 0; text-decoration:underline;">View Items</button>
                    </div>
                    <div style="display:flex;align-items:center;gap:8px;">
                        <button onclick="window.sharePastInvoicePDF(${s.timestamp})" style="background:rgba(18,140,126,0.1);border:1px solid rgba(18,140,126,0.2);color:#25D366;border-radius:8px;width:32px;height:32px;display:flex;align-items:center;justify-content:center;cursor:pointer;"><i data-lucide="file-text" style="width:14px;"></i></button>
                        <button onclick="window.deleteInvoice(${s.timestamp})" style="background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.2);color:var(--accent-danger);border-radius:8px;width:32px;height:32px;display:flex;align-items:center;justify-content:center;cursor:pointer;"><i data-lucide="trash-2" style="width:14px;"></i></button>
                    </div>
                </div>
                <!-- Expandable details -->
                <div class="order-details-drawer" style="max-height:0;overflow:hidden;transition:max-height 0.3s ease-out;background:rgba(0,0,0,0.15);margin:10px -18px -14px;padding:0 18px;">
                    <div style="padding:15px 0;">
                        <div style="font-size:0.7rem;text-transform:uppercase;color:#64748b;font-weight:700;letter-spacing:1px;margin-bottom:8px;">Purchased Items</div>
                        ${itemDetails}
                    </div>
                </div>
            </div>`;
    }).join('') || '<div class="empty-state">No orders found in history.</div>';

    dashboardView.innerHTML = `
        <div class="welcome-banner glass-panel">
            <div>
                <h3>MJ Enterprises CRM</h3>
                <p>Welcome to your central administration console.</p>
            </div>
            <div>
                <img src="assets/logo.jpeg" alt="Logo" style="width:120px;height:120px;object-fit:cover;border-radius:50%;border:3px solid rgba(255,255,255,0.1);box-shadow:0 8px 20px rgba(0,0,0,0.2);" onerror="this.style.display='none'">
            </div>
        </div>

        <div class="grid-4 mb-4">
            <div class="stat-card">
                <div class="flex-between"><span class="stat-icon" style="color:var(--accent-emerald);"><i data-lucide="dollar-sign"></i></span></div>
                <div class="stat-details"><span class="label">Today's Sales</span><span class="value">${window.formatCurrency(todaySales)}</span></div>
            </div>
            <div class="stat-card warning">
                <div class="flex-between"><span class="stat-icon" style="color:var(--accent-orange);"><i data-lucide="clock"></i></span></div>
                <div class="stat-details"><span class="label">Pending Invoices</span><span class="value">${window.formatCurrency(pendingSales)}</span></div>
            </div>
            <div class="stat-card danger">
                <div class="flex-between"><span class="stat-icon" style="color:var(--accent-danger);"><i data-lucide="trending-down"></i></span></div>
                <div class="stat-details"><span class="label">Period Expenses</span><span class="value">${window.formatCurrency(periodExps + periodSalary)}</span></div>
            </div>
            <div class="stat-card blue">
                <div class="flex-between">
                    <span class="stat-icon" style="color:var(--accent-blue);"><i data-lucide="trending-up"></i></span>
                    <select onchange="window.switchProfitPeriod(this.value)" style="width:auto;padding:4px 8px;font-size:0.75rem;background:rgba(0,0,0,0.2);border:1px solid rgba(255,255,255,0.1);color:white;border-radius:6px;outline:none;">
                        <option value="today" ${currentProfitPeriod === 'today' ? 'selected' : ''}>Today</option>
                        <option value="week" ${currentProfitPeriod === 'week' ? 'selected' : ''}>Weekly</option>
                        <option value="month" ${currentProfitPeriod === 'month' ? 'selected' : ''}>Monthly</option>
                        <option value="year" ${currentProfitPeriod === 'year' ? 'selected' : ''}>Yearly</option>
                    </select>
                </div>
                <div class="stat-details">
                    <span class="label">${currentProfitPeriod.charAt(0).toUpperCase() + currentProfitPeriod.slice(1)} Profit</span>
                    <span class="value" style="color:${periodProfit>=0?'var(--accent-emerald)':'var(--accent-danger)'}">${window.formatCurrency(periodProfit)}</span>
                </div>
            </div>
        </div>

        <!-- ══ PENDING SECTIONS SIDE BY SIDE ════════════════════════════ -->
        <div class="responsive-grid-2" style="margin-bottom:22px;">
            ${buildPendingCustomersSection(sales)}
            ${buildPendingExpensesSection(receipts)}
        </div>

        <!-- ══ TRANSACTION + ADD EXPENSE ═══════════════════════════════════ -->
        <div class="responsive-grid-2">
            <div class="card" style="display:flex;flex-direction:column;max-height:800px;">
                <div class="flex-between mb-4">
                    <h3 style="margin:0;">All Orders & Customer Details</h3>
                    <div style="font-size:0.8rem;color:#64748b;">${allOrders.length} Total Records</div>
                </div>
                <div style="flex:1;overflow-y:auto;padding-right:10px;">${recentSalesHtml}</div>
            </div>
            <div style="display:flex;flex-direction:column;gap:22px;">
                <div class="card" style="border-top: 4px solid var(--accent-danger);">
                    <div class="flex-between mb-4">
                        <h3 style="margin:0;">Quick Expense Record</h3>
                        <i data-lucide="plus-circle" style="color:var(--accent-danger); width: 24px;"></i>
                    </div>
                    <div style="display:flex;flex-direction:column;gap:12px;">
                        <div class="form-group" style="margin: 0;">
                            <label style="font-size: 0.75rem;">Category</label>
                            <select id="dash-exp-category" style="padding: 10px;">
                                <option value="Groceries">Groceries / Raw Materials</option>
                                <option value="Van Service">Van Service</option>
                                <option value="Petrol">Petrol / Fuel</option>
                                <option value="Utilities">Utilities</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="form-group" style="margin: 0;">
                            <label style="font-size: 0.75rem;">Amount (₹)</label>
                            <input type="number" id="dash-exp-amt" placeholder="e.g. 500" style="padding: 10px;">
                        </div>
                        <button class="btn btn-danger" onclick="window.recordDashboardExpense()" style="width:100%; padding: 10px;">
                            <i data-lucide="save" style="width:14px;"></i> Save Expense
                        </button>
                    </div>
                </div>
                <div class="card">
                    <h3>Quick Actions</h3>
                    <div class="grid-2 mt-4">
                        <button class="btn btn-primary" style="height:100px;flex-direction:column;font-size:1rem;" onclick="document.querySelector('[data-view=\\'billing\\']').click()">
                            <i data-lucide="plus" style="width:24px; margin-bottom: 5px;"></i>New Invoice
                        </button>
                        <button class="btn btn-secondary" style="height:100px;flex-direction:column;font-size:1rem;" onclick="document.querySelector('[data-view=\\'employees\\']').click()">
                            <i data-lucide="users" style="width:24px; margin-bottom: 5px;"></i>Employees
                        </button>
                        <button class="btn btn-warning" style="height:100px;flex-direction:column;font-size:1rem; grid-column: span 2;" onclick="document.querySelector('[data-view=\\'history\\']').click()">
                            <i data-lucide="list" style="width:24px; margin-bottom: 5px;"></i>View Full History
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Re-initialize Lucide Icons after content change
    if (window.lucide) window.lucide.createIcons();
};

window.switchProfitPeriod = (period) => {
    currentProfitPeriod = period;
    window.refreshDashboard();
};

window.recordDashboardExpense = () => {
    const category = document.getElementById('dash-exp-category').value;
    const amt = parseFloat(document.getElementById('dash-exp-amt').value);
    
    if (!amt || amt <= 0) {
        alert('Please enter a valid amount');
        return;
    }

    const expense = { id: Date.now(), category, amt, note: 'Dashboard Entry', timestamp: Date.now() };
    let exps = JSON.parse(localStorage.getItem('mj_expenses') || '[]');
    exps.push(expense);
    localStorage.setItem('mj_expenses', JSON.stringify(exps));
    
    document.getElementById('dash-exp-amt').value = '';
    window.refreshDashboard();
    
    // Optional: show toast if we have a global toast function
    if (window.showExpToast) window.showExpToast(`Recorded ₹${amt} as ${category}`, 'success');
};

// ── Pending Customers ─────────────────────────────────────────────────────────
function buildPendingCustomersSection(sales) {
    const pending = sales.filter(s => s.status === 'Pending')
        .sort((a,b) => a.timestamp - b.timestamp); // oldest first

    if (pending.length === 0) {
        return `<div class="card" style="border-top:4px solid #10b981;">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px;">
                <i data-lucide="check-circle" style="color:#10b981; width: 20px;"></i>
                <h3 style="margin:0;color:#34d399;">Customer Payments</h3>
            </div>
            <p style="color:#64748b;font-size:0.88rem;margin:8px 0 0;">All invoices are settled — no pending payments.</p>
        </div>`;
    }

    const totalPending = pending.reduce((a,c) => a + c.total, 0);
    const rows = pending.map(s => {
        const date = new Date(s.timestamp).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});
        const time = new Date(s.timestamp).toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});
        const daysAgo = Math.floor((Date.now() - s.timestamp) / 86400000);
        const ageBadge = daysAgo === 0
            ? `<span style="color:#fbbf24;font-size:0.7rem;">Today</span>`
            : `<span style="color:#f87171;font-size:0.7rem;">${daysAgo}d ago</span>`;
        return `
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.05);">
            <div style="min-width:0;">
                <div style="font-weight:700;color:#f1f5f9;font-size:0.92rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${s.shop || 'Walk-in'}</div>
                <div style="font-size:0.72rem;color:#64748b;margin-top:2px;">${date} · ${time} &nbsp; ${ageBadge}</div>
            </div>
            <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;">
                <span style="font-weight:800;color:#fbbf24;font-size:0.95rem;">${window.formatCurrency(s.total)}</span>
                <button onclick="window.markInvoicePaid(${s.timestamp})"
                    style="background:rgba(16,185,129,0.12);color:#34d399;border:1px solid rgba(16,185,129,0.25);border-radius:7px;padding:5px 10px;font-size:0.75rem;font-weight:700;cursor:pointer;font-family:inherit;white-space:nowrap;">
                    ✓ Paid
                </button>
            </div>
        </div>`;
    }).join('');

    return `
    <div class="card" style="border-top:4px solid #f59e0b;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
            <div style="display:flex;align-items:center;gap:8px;">
                <i data-lucide="clock" style="color:#f59e0b; width: 22px;"></i>
                <h3 style="margin:0;">Pending Customer Payments</h3>
            </div>
            <div style="text-align:right;">
                <div style="font-weight:800;font-size:1.05rem;color:#fbbf24;">${window.formatCurrency(totalPending)}</div>
                <div style="font-size:0.7rem;color:#64748b;">${pending.length} invoice${pending.length>1?'s':''}</div>
            </div>
        </div>
        <div style="max-height:300px;overflow-y:auto;">${rows}</div>
    </div>`;
}

// ── Pending Expense Receipts ──────────────────────────────────────────────────
function buildPendingExpensesSection(receipts) {
    const unpaid = receipts.filter(r => !r.paid)
        .sort((a,b) => new Date(a.dateVal) - new Date(b.dateVal)); // oldest bill first

    if (unpaid.length === 0) {
        return `<div class="card" style="border-top:4px solid #10b981;">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px;">
                <i data-lucide="check-circle" style="color:#10b981; width: 20px;"></i>
                <h3 style="margin:0;color:#34d399;">Expense Bills</h3>
            </div>
            <p style="color:#64748b;font-size:0.88rem;margin:8px 0 0;">All expense bills are paid — nothing pending.</p>
        </div>`;
    }

    const totalUnpaid = unpaid.reduce((a,c) => a + c.amt, 0);
    const rows = unpaid.map(r => {
        const date = new Date(r.dateVal + 'T00:00:00').toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});
        const daysAgo = Math.floor((Date.now() - new Date(r.dateVal).getTime()) / 86400000);
        const ageBadge = daysAgo === 0
            ? `<span style="color:#fbbf24;font-size:0.7rem;">Today</span>`
            : `<span style="color:#f87171;font-size:0.7rem;">${daysAgo}d old</span>`;
        return `
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.05);">
            <div style="min-width:0;flex:1;">
                <div style="font-weight:700;color:#f1f5f9;font-size:0.92rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${r.shop}</div>
                <div style="font-size:0.72rem;color:#8b5cf6;margin-top:1px;">${r.category}</div>
                <div style="font-size:0.7rem;color:#64748b;margin-top:1px;">📅 ${date} &nbsp; ${ageBadge}</div>
            </div>
            <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;">
                <span style="font-weight:800;color:#ef4444;font-size:0.95rem;">${window.formatCurrency(r.amt)}</span>
                <button onclick="window.dashMarkReceiptPaid(${r.id})"
                    style="background:rgba(16,185,129,0.12);color:#34d399;border:1px solid rgba(16,185,129,0.25);border-radius:7px;padding:5px 10px;font-size:0.75rem;font-weight:700;cursor:pointer;font-family:inherit;white-space:nowrap;">
                    ✓ Paid
                </button>
            </div>
        </div>`;
    }).join('');

    return `
    <div class="card" style="border-top:4px solid #ef4444;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;">
            <div style="display:flex;align-items:center;gap:8px;">
                <i data-lucide="file-text" style="color:#ef4444; width: 22px;"></i>
                <h3 style="margin:0;">Pending Expense Bills</h3>
            </div>
            <div style="text-align:right;">
                <div style="font-weight:800;font-size:1.05rem;color:#ef4444;">${window.formatCurrency(totalUnpaid)}</div>
                <div style="font-size:0.7rem;color:#64748b;">${unpaid.length} bill${unpaid.length>1?'s':''}</div>
            </div>
        </div>
        <div style="max-height:300px;overflow-y:auto;">${rows}</div>
    </div>`;
}

// Mark receipt as paid from the dashboard
window.dashMarkReceiptPaid = (id) => {
    let receipts = JSON.parse(localStorage.getItem('mj_receipts') || '[]');
    const r = receipts.find(r => r.id === id);
    if (!r) return;
    r.paid = true;
    localStorage.setItem('mj_receipts', JSON.stringify(receipts));
    window.refreshDashboard();
};

window.deleteInvoice = (timestamp) => {
    if(!confirm("Are you sure you want to delete this invoice? The daily stats and dashboard will be recalculated.")) return;
    
    let sales = JSON.parse(localStorage.getItem('mj_sales') || '[]');
    sales = sales.filter(s => s.timestamp !== timestamp);
    localStorage.setItem('mj_sales', JSON.stringify(sales));
    
    if(window.refreshDashboard) window.refreshDashboard();
    if(window.initHistory) window.initHistory();
};

window.markInvoicePaid = (timestamp) => {
    let sales = JSON.parse(localStorage.getItem('mj_sales') || '[]');
    const index = sales.findIndex(s => s.timestamp === timestamp);
    if(index > -1) {
        sales[index].status = 'Paid';
        localStorage.setItem('mj_sales', JSON.stringify(sales));
        if(window.refreshDashboard) window.refreshDashboard();
        if(window.initHistory) window.initHistory();
    }
};

window.markInvoiceUnpaid = (timestamp) => {
    let sales = JSON.parse(localStorage.getItem('mj_sales') || '[]');
    const index = sales.findIndex(s => s.timestamp === timestamp);
    if(index > -1) {
        sales[index].status = 'Pending';
        localStorage.setItem('mj_sales', JSON.stringify(sales));
        if(window.refreshDashboard) window.refreshDashboard();
        if(window.initHistory) window.initHistory();
    }
};
